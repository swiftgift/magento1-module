alter table sggift_gift add column `share_url` varchar(255);
